﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;
using HtmlAgilityPack;
using System.IO;
namespace Google_Recon
{
    public partial class Form1 : Form
    {

        string itemtoshow,apiUrl;
        string query = "test";
        int n_pages = 10;
        int start = 0;
        int selectedprev;
        string listboxmyselected;
        string comboboxselect = "";
        string myurl = "https://test.com";
        string apiUrl2;
        string classnode = "//div[@class='yuRUbf']";
        string engine = "classtest";
        string comboosint = "test";
        int dirb = 0;
        string dirbselected = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.ca/search?q=" + textBox1.Text + "&cr=countryCA&biw=1536&bih=754&tbs=ctr:countryCA&ei=N_EIYdSkI4H1-Qbl2ojICw&oq=" + textBox1.Text + "&gs_lcp=Cgdnd3Mtd2l6EAMyBQgAEIAEMgUIABCABDIFCAAQgAQyBQgAEIAEMgUIABCABDIFCAAQgAQyBQgAEIAEMgUIABCABDIFCAAQgAQyBQgAEIAEOggIABCxAxCDAToLCAAQgAQQsQMQgwE6BQguEIAEOggILhCxAxCDAToRCC4QgAQQsQMQgwEQxwEQowI6DgguEIAEELEDEMcBEKMCOg4ILhCABBCxAxDHARDRAzoECAAQQzoKCC4QxwEQowIQQzoNCC4QsQMQxwEQ0QMQQzoHCAAQyQMQQzoFCAAQkgM6CAgAEIAEELEDOgcIABCxAxBDOgoILhDHARDRAxBDOgoIABCABBBGEP8BSgQIQRgAUOKtAVix0wFg1dQBaABwAngAgAHJAYgBlRySAQcxMi4xNy4xmAEAoAEBwAEB&sclient=gws-wiz&ved=0ahUKEwiUnLmVq5TyAhWBet4KHWUtArkQ4dUDCA4&uact=5");

            }
            if (checkBox2.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.ca/search?q=" + textBox1.Text + "&cr=countryCA&tbs=ctr:countryCA,qdr:w&source=lnt&sa=X&ved=2ahUKEwiSiPaiq5TyAhVBaN4KHQCMCYAQpwV6BAgBECc&biw=1536&bih=754");

            }
            if (checkBox3.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.ca/search?q=" + textBox1.Text + "&cr=countryCA&tbs=ctr:countryCA,qdr:m&source=lnt&sa=X&ved=2ahUKEwixvsDPq5TyAhUPCd4KHak7BA8QpwV6BAgCECg&biw=1536&bih=754");


            }
            if (checkBox4.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.ca/search?q=" + textBox1.Text + "&cr=countryCA&biw=1536&bih=754&source=lnt&tbs=ctr:countryCA,cdr:1,cd_min:" + textBox2.Text + ",cd_max:" + textBox3.Text + "&tbm=");


            }
            if (checkBox5.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.co.uk/search?q=" + textBox1.Text + "&cr=countryUK&biw=1536&bih=754&tbs=ctr:countryUK&ei=N_EIYdSkI4H1-Qbl2ojICw&oq=" + textBox1.Text + "&gs_lcp=Cgdnd3Mtd2l6EAMyBQgAEIAEMgUIABCABDIFCAAQgAQyBQgAEIAEMgUIABCABDIFCAAQgAQyBQgAEIAEMgUIABCABDIFCAAQgAQyBQgAEIAEOggIABCxAxCDAToLCAAQgAQQsQMQgwE6BQguEIAEOggILhCxAxCDAToRCC4QgAQQsQMQgwEQxwEQowI6DgguEIAEELEDEMcBEKMCOg4ILhCABBCxAxDHARDRAzoECAAQQzoKCC4QxwEQowIQQzoNCC4QsQMQxwEQ0QMQQzoHCAAQyQMQQzoFCAAQkgM6CAgAEIAEELEDOgcIABCxAxBDOgoILhDHARDRAxBDOgoIABCABBBGEP8BSgQIQRgAUOKtAVix0wFg1dQBaABwAngAgAHJAYgBlRySAQcxMi4xNy4xmAEAoAEBwAEB&sclient=gws-wiz&ved=0ahUKEwiUnLmVq5TyAhWBet4KHWUtArkQ4dUDCA4&uact=5");

            }
            if (checkBox6.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.co.uk/search?q=" + textBox1.Text + "&cr=countryUK&tbs=ctr:countryUK,qdr:w&source=lnt&sa=X&ved=2ahUKEwiSiPaiq5TyAhVBaN4KHQCMCYAQpwV6BAgBECc&biw=1536&bih=754");

            }
            if (checkBox7.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.co.uk/search?q=" + textBox1.Text + "&cr=countryUK&tbs=ctr:countryUK,qdr:m&source=lnt&sa=X&ved=2ahUKEwixvsDPq5TyAhUPCd4KHak7BA8QpwV6BAgCECg&biw=1536&bih=754");


            }
            if (checkBox8.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.co.uk/search?q=" + textBox1.Text + "&cr=countryUK&biw=1536&bih=754&source=lnt&tbs=ctr:countryUK,cdr:1,cd_min:" + textBox2.Text + ",cd_max:" + textBox3.Text + "&tbm=");


            }

            //

            if (checkBox9.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.nl/search?q=" + textBox1.Text + "&cr=countryNL&biw=1536&bih=754&tbs=ctr:countryNL&ei=N_EIYdSkI4H1-Qbl2ojICw&oq=" + textBox1.Text + "&gs_lcp=Cgdnd3Mtd2l6EAMyBQgAEIAEMgUIABCABDIFCAAQgAQyBQgAEIAEMgUIABCABDIFCAAQgAQyBQgAEIAEMgUIABCABDIFCAAQgAQyBQgAEIAEOggIABCxAxCDAToLCAAQgAQQsQMQgwE6BQguEIAEOggILhCxAxCDAToRCC4QgAQQsQMQgwEQxwEQowI6DgguEIAEELEDEMcBEKMCOg4ILhCABBCxAxDHARDRAzoECAAQQzoKCC4QxwEQowIQQzoNCC4QsQMQxwEQ0QMQQzoHCAAQyQMQQzoFCAAQkgM6CAgAEIAEELEDOgcIABCxAxBDOgoILhDHARDRAxBDOgoIABCABBBGEP8BSgQIQRgAUOKtAVix0wFg1dQBaABwAngAgAHJAYgBlRySAQcxMi4xNy4xmAEAoAEBwAEB&sclient=gws-wiz&ved=0ahUKEwiUnLmVq5TyAhWBet4KHWUtArkQ4dUDCA4&uact=5");

            }
            if (checkBox10.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.nl/search?q=" + textBox1.Text + "&cr=countryNL&tbs=ctr:countryNL,qdr:w&source=lnt&sa=X&ved=2ahUKEwiSiPaiq5TyAhVBaN4KHQCMCYAQpwV6BAgBECc&biw=1536&bih=754");

            }
            if (checkBox11.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.nl/search?q=" + textBox1.Text + "&cr=countryNL&tbs=ctr:countryNL,qdr:m&source=lnt&sa=X&ved=2ahUKEwixvsDPq5TyAhUPCd4KHak7BA8QpwV6BAgCECg&biw=1536&bih=754");


            }
            if (checkBox12.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.nl/search?q=" + textBox1.Text + "&cr=countryNL&biw=1536&bih=754&source=lnt&tbs=ctr:countryNL,cdr:1,cd_min:" + textBox2.Text + ",cd_max:" + textBox3.Text + "&tbm=");


            }
            //

            if (checkBox13.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.fr/search?q=" + textBox1.Text + "&cr=countryFR&biw=1536&bih=754&tbs=ctr:countryFR&ei=N_EIYdSkI4H1-Qbl2ojICw&oq=" + textBox1.Text + "&gs_lcp=Cgdnd3Mtd2l6EAMyBQgAEIAEMgUIABCABDIFCAAQgAQyBQgAEIAEMgUIABCABDIFCAAQgAQyBQgAEIAEMgUIABCABDIFCAAQgAQyBQgAEIAEOggIABCxAxCDAToLCAAQgAQQsQMQgwE6BQguEIAEOggILhCxAxCDAToRCC4QgAQQsQMQgwEQxwEQowI6DgguEIAEELEDEMcBEKMCOg4ILhCABBCxAxDHARDRAzoECAAQQzoKCC4QxwEQowIQQzoNCC4QsQMQxwEQ0QMQQzoHCAAQyQMQQzoFCAAQkgM6CAgAEIAEELEDOgcIABCxAxBDOgoILhDHARDRAxBDOgoIABCABBBGEP8BSgQIQRgAUOKtAVix0wFg1dQBaABwAngAgAHJAYgBlRySAQcxMi4xNy4xmAEAoAEBwAEB&sclient=gws-wiz&ved=0ahUKEwiUnLmVq5TyAhWBet4KHWUtArkQ4dUDCA4&uact=5");

            }
            if (checkBox14.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.fr/search?q=" + textBox1.Text + "&cr=countryFR&tbs=ctr:countryFR,qdr:w&source=lnt&sa=X&ved=2ahUKEwiSiPaiq5TyAhVBaN4KHQCMCYAQpwV6BAgBECc&biw=1536&bih=754");

            }
            if (checkBox15.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.fr/search?q=" + textBox1.Text + "&cr=countryFR&tbs=ctr:countryFR,qdr:m&source=lnt&sa=X&ved=2ahUKEwixvsDPq5TyAhUPCd4KHak7BA8QpwV6BAgCECg&biw=1536&bih=754");


            }
            if (checkBox16.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.fr/search?q=" + textBox1.Text + "&cr=countryFR&biw=1536&bih=754&source=lnt&tbs=ctr:countryFR,cdr:1,cd_min:" + textBox2.Text + ",cd_max:" + textBox3.Text + "&tbm=");


            }

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Text = listBox1.SelectedItem.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            checkBox1.Checked = true;
            checkBox5.Checked = true;
            checkBox9.Checked = true;
            checkBox13.Checked = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            checkBox2.Checked = true;
            checkBox6.Checked = true;
            checkBox10.Checked = true;
            checkBox14.Checked = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            checkBox3.Checked = true;
            checkBox7.Checked = true;
            checkBox11.Checked = true;
            checkBox15.Checked = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            checkBox4.Checked = true;
            checkBox8.Checked = true;
            checkBox12.Checked = true;
            checkBox16.Checked = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (checkBox17.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.com/search?q=" + textBox4.Text + " " + textBox5.Text);


            }

            if (checkBox18.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.com/search?q=" + textBox4.Text + " " + textBox5.Text);

            }
            if (checkBox19.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.com/search?q=" + textBox4.Text + " " + textBox5.Text);

            }

            if (checkBox20.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.com/search?q=" + textBox4.Text + " " + textBox5.Text);

            }
            if (checkBox21.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.com/search?q=" + textBox4.Text + " " + textBox5.Text);

            }
            if (checkBox22.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.com/search?q=site:" + textBox4.Text + " " + textBox5.Text);

            }
            if (checkBox23.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.com/search?q=site:" + textBox4.Text + " " + textBox5.Text);

            }
            if (checkBox24.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.com/search?q=site:" + textBox4.Text + " " + textBox5.Text);

            }
            if (checkBox25.Checked == true)
            {
                System.Diagnostics.Process.Start("https://www.google.com/search?q=site:" + textBox4.Text + " " + textBox5.Text);

            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            listBox2.Items.Add(textBox4.Text);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (checkBox17.Checked == true)
            {
                foreach (var items in listBox2.Items)
                {
                    System.Diagnostics.Process.Start("https://www.google.com/search?q=site:" + items + " " + textBox5.Text);

                }
            }
            if (checkBox18.Checked == true)
            {

                foreach (var items in listBox2.Items)
                {
                    System.Diagnostics.Process.Start("https://www.google.com/search?q=site:" + items + " " + textBox5.Text);

                }
                // MessageBox.Show(items.ToString());

            }

            if (checkBox19.Checked == true)
            {

                foreach (var items in listBox2.Items)
                {
                    System.Diagnostics.Process.Start("https://www.google.com/search?q=site:" + items + " " + textBox5.Text);

                }


            }

            if (checkBox20.Checked == true)
            {

                foreach (var items in listBox2.Items)
                {
                    System.Diagnostics.Process.Start("https://www.google.com/search?q=site:" + items + " " + textBox5.Text);

                }


            }
            if (checkBox21.Checked == true)
            {

                foreach (var items in listBox2.Items)
                {
                    System.Diagnostics.Process.Start("https://www.google.com/search?q=site:" + items + " " + textBox5.Text);

                }


            }
            if (checkBox22.Checked == true)
            {

                foreach (var items in listBox2.Items)
                {
                    System.Diagnostics.Process.Start("https://www.google.com/search?q=site:" + items + " " + textBox5.Text);

                }


            }
            if (checkBox23.Checked == true)
            {

                foreach (var items in listBox2.Items)
                {
                    System.Diagnostics.Process.Start("https://www.google.com/search?q=site:" + items + " " + textBox5.Text);

                }


            }
            if (checkBox24.Checked == true)
            {

                foreach (var items in listBox2.Items)
                {
                    System.Diagnostics.Process.Start("https://www.google.com/search?q=site:" + items + " " + textBox5.Text);

                }


            }

            if (checkBox25.Checked == true)
            {

                foreach (var items in listBox2.Items)
                {
                    System.Diagnostics.Process.Start("https://www.google.com/search?q=site:" + items + " " + textBox5.Text);

                }


            }
        }

        private void checkBox19_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox19.Checked == true)
            {
                textBox5.Text = "ext:xml | ext:conf | ext:cnf | ext:reg | ext:inf | ext:rdp | ext:cfg | ext:txt | ext:ora | ext:ini";
            }
        }

        private void checkBox17_CheckedChanged(object sender, EventArgs e)
        {
            textBox5.Text = "blog+wp-content";

        }

        private void checkBox18_CheckedChanged(object sender, EventArgs e)
        {
            textBox5.Text = "+intitle:index.of";
        }

        private void button9_Click(object sender, EventArgs e)
        {

            textBox5.Text = "blog+wp-content";
            System.Diagnostics.Process.Start("https://www.google.com/search?q=site:" + textBox4.Text + " " + textBox5.Text);

            textBox5.Text = "+intitle:index.of";
            System.Diagnostics.Process.Start("https://www.google.com/search?q=site:" + textBox4.Text + " " + textBox5.Text);

            textBox5.Text = "ext:xml | ext:conf | ext:cnf | ext:reg | ext:inf | ext:rdp | ext:cfg | ext:txt | ext:ora | ext:ini";
            System.Diagnostics.Process.Start("https://www.google.com/search?q=site:" + textBox4.Text + " " + textBox5.Text);

            textBox5.Text = "inurl:wp- | inurl:wp-content | inurl:plugins | inurl:uploads | inurl:themes | inurl:download";
            System.Diagnostics.Process.Start("https://www.google.com/search?q=site:" + textBox4.Text + " " + textBox5.Text);

            textBox5.Text = "filetype:config 'apache'";
            System.Diagnostics.Process.Start("https://www.google.com/search?q=site:" + textBox4.Text + " " + textBox5.Text);

            textBox5.Text = "inurl:redir | inurl:url | inurl:redirect | inurl:return | inurl:src=http | inurl:r=http";
            System.Diagnostics.Process.Start("https://www.google.com/search?q=site:" + textBox4.Text + " " + textBox5.Text);

            textBox5.Text = "ext:action | ext:struts | ext:do";
            System.Diagnostics.Process.Start("https://www.google.com/search?q=site:" + textBox4.Text + " " + textBox5.Text);

            textBox5.Text = "inurl:' / phpinfo.php' | inurl:'.htaccess'";
            System.Diagnostics.Process.Start("https://www.google.com/search?q=site:" + textBox4.Text + " " + textBox5.Text);

            textBox5.Text = "filetype:wsdl | filetype:WSDL | ext:svc | inurl:wsdl | Filetype: ?wsdl | inurl:asmx?wsdl | inurl:jws?wsdl | intitle:_vti_bin/sites.asmx?wsdl | inurl:_vti_bin/sites.asmx?wsdl";
            System.Diagnostics.Process.Start("https://www.google.com/search?q=site:" + textBox4.Text + " " + textBox5.Text);

        }

        private void checkBox20_CheckedChanged(object sender, EventArgs e)
        {
            textBox5.Text = "inurl:wp- | inurl:wp-content | inurl:plugins | inurl:uploads | inurl:themes | inurl:download";
        }

        private void checkBox21_CheckedChanged(object sender, EventArgs e)
        {
            textBox5.Text = "filetype:config 'apache'";
        }

        private void checkBox22_CheckedChanged(object sender, EventArgs e)
        {
            textBox5.Text = "inurl:redir | inurl:url | inurl:redirect | inurl:return | inurl:src=http | inurl:r=http";
        }

        private void checkBox23_CheckedChanged(object sender, EventArgs e)
        {
            textBox5.Text = "ext:action | ext:struts | ext:do";
        }

        private void checkBox24_CheckedChanged(object sender, EventArgs e)
        {
            textBox5.Text = "inurl:' / phpinfo.php' | inurl:'.htaccess'";
        }

        private void checkBox25_CheckedChanged(object sender, EventArgs e)
        {
            textBox5.Text = " filetype: wsdl | filetype:WSDL | ext:svc | inurl:wsdl | Filetype: ?wsdl | inurl:asmx? wsdl | inurl:jws? wsdl | intitle:_vti_bin / sites.asmx ? wsdl | inurl : _vti_bin / sites.asmx ? wsdl";
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void Caluculate(int i)
        {
            double pow = Math.Pow(i, i);
        }
        private void button10_Click(object sender, EventArgs e)
        {
            listBox3.Items.Add(textBox7.Text);


           // progressBar1.Maximum = 100000;
           // progressBar1.Step = 1;

          //  for (int j = 0; j < 100000; j++)
           // {
           //     Caluculate(j);
            //    progressBar1.PerformStep();
           // }
            
        }

        private async void button11_Click(object sender, EventArgs e)
        {

            getmethod();
        }


        private async void getmethod()
        {
            

            // string apiUrl = textBox7.Text;
            string apiUrl = listBox3.SelectedItem.ToString()+textBox13.Text;
            textBox14.Text = apiUrl;
            // Create an instance of HttpClient
            using (HttpClient client = new HttpClient())
               
            {
                try
                {

                    // Send the GET request
                    client.DefaultRequestHeaders.UserAgent.ParseAdd("Mozilla/5.0 (compatible; AcmeInc/1.0)");
                    client.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json; charset=utf-8");
                    HttpResponseMessage response = await client.GetAsync(apiUrl);

                    // Check if the request was successful (status code 200-299)
                    if (response.IsSuccessStatusCode)
                    {
                        // Read and print the response content as a string
                        string responseBody = await response.Content.ReadAsStringAsync();

                        Console.WriteLine(responseBody);
                        textBox6.Text = responseBody;
                        textBox8.Text = response.Headers.ToString();
                        

                    }
                    else
                    {
                        Console.WriteLine($"Error: {response.StatusCode} - {response.ReasonPhrase}");
                        textBox6.Text = ($"Error: {response.StatusCode} - {response.ReasonPhrase}");
                        
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Exception: {ex.Message}");
                    MessageBox.Show(ex.Message);
                   
                }
            }
          
            timer1.Stop();
            timer1.Start();
        }



        private async void button12_Click(object sender, EventArgs e)
        {


            foreach (var item in listBox4.Items)
            {
                listBox3.Items.Add(item);
            }

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            if (textBox6.Text.Contains(textBox9.Text))
            {
                selectedprev = listBox3.SelectedIndex - 1;
                listboxmyselected = listBox3.Items[selectedprev].ToString();
                richTextBox1.Text += ("\n" + "MATCH FOUND FOR :  " + " ") + (itemtoshow.ToString()) + " in the URL :- " + listboxmyselected;

                richTextBox2.Text += ("MATCH by function : ");

            }
            

        }

        private void button13_Click(object sender, EventArgs e)
        {
           
            
            if (comboBox1.SelectedIndex==0)
            {
                myurl = "http://www.google.com/search?q=";
            }
            else if (comboBox1.SelectedIndex == 1)
            {
                myurl = "http://www.google.ca/search?q=";
            }
            else if (comboBox1.SelectedIndex == 2)
            {
                myurl = "http://www.google.nl/search?q=";
            }
            else if (comboBox1.SelectedIndex == 3)
            {
                myurl = "http://www.google.fr/search?q=";
            }
            else if (comboBox1.SelectedIndex == 4)
            {
                int zero = 0;
               // myurl = "https://in.search.yahoo.com/search;_ylt=Awrx.bum4GBlET8aH4e7HAx.;_ylu=Y29sbwNzZzMEcG9zAzEEdnRpZAMEc2VjA3BhZ2luYXRpb24-?p="+textBox10.Text+"&pz=7&fr=sfp&fr2=p%3As%2Cv%3Asfp%2Cm%3Asb-top&pz=7&xargs=0&b="+n_pages/10+zero+"?";
                myurl = "https://in.search.yahoo.com/search;?p=";
                //https://in.search.yahoo.com/search;_ylt=Awrx.bum4GBlET8aH4e7HAx.;_ylu=Y29sbwNzZzMEcG9zAzEEdnRpZAMEc2VjA3BhZ2luYXRpb24-?p=test&pz=7&fr=sfp&fr2=p%3As%2Cv%3Asfp%2Cm%3Asb-top&pz=7&xargs=0&b=30
            }
            else if (comboBox1.SelectedIndex == 5)
            {
                myurl = "https://www.bing.com/search?q=";
                //https://www.bing.com/search?q=aaa&sp=-1&ghc=1&lq=0&pq=aaa&sc=11-3&qs=n&sk=&cvid=576FC51CD8BD4C8E92EF2FDE33334089&ghsh=0&ghacc=0&ghpl=&FPIG=4AD4DC63926D4A9BA2B1EF7BC60B33D4&FORM=PERE&first=50
            }

            //compTitle options-toggle
            query = myurl+ textBox10.Text;
            
            n_pages = Convert.ToInt32(textBox11.Text);
            Console.WriteLine("Welcome To Google SERP Scraper");
            var results = ScrapeSerp(query, n_pages, engine);
            foreach (var result in results)
            {
                Console.WriteLine(result.Title);
                Console.WriteLine(result.Url);
                listBox4.Items.Add(result.Url);
            }
            Console.ReadLine();
        }


        public static List<serpResult> ScrapeSerp(string query, int n_pages, string engine)
        {

            var serpResults = new List<serpResult>();
            for (var i = 1; i <= n_pages; i++)
            { 
              
                var url =   query + " &num="+(n_pages)+" &start=" + ((i - 1) * 10).ToString();
                
                
                HtmlWeb web = new HtmlWeb();
                web.UserAgent = "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36";
                  MessageBox.Show(query);
                var htmldoc = web.Load(url);
                //compTitle options-toggle
                Form1 frm = new Form1();

                // HtmlNodeCollection Nodes = htmldoc.DocumentNode.SelectNodes("//div[@class='yuRUbf']");
                //  HtmlNodeCollection Nodes = htmldoc.DocumentNode.SelectNodes("//div[@class='compTitle options-toggle']");

                //MessageBox.Show("textbox12 is " + engine);
                    HtmlNodeCollection Nodes = htmldoc.DocumentNode.SelectNodes(engine);
                    MessageBox.Show(Nodes.ToString());

                    foreach (var tag in Nodes)
                    {
                        var result = new serpResult();
                        result.Url = tag.Descendants("a").FirstOrDefault().Attributes["href"].Value;
                      //  result.Title = tag.Descendants("h3").FirstOrDefault().InnerText;
                        serpResults.Add(result);
                    }
               
                    
                
               // HtmlNodeCollection Nodes = htmldoc.DocumentNode.SelectNodes("//div[@class='yuRUbf']");
                

            }

            return serpResults;
        }
        public class serpResult
        {
            public string Url { get; set; }
            public string Title { get; set; }
        }
       
        private void button14_Click(object sender, EventArgs e)
        {
            listBox5.SelectedIndex = 0;
            apiUrl2 = listBox5.SelectedItem.ToString();

            timer2.Start();


            //for (int i = 0; i < listBox4.Items.Count; i++)
            //{
            //    listBox4.SelectedItem = listBox4.Items[i];
            //    string show = listBox4.SelectedItem.ToString();
            //    MessageBox.Show("Selceted item is " + show);
            //Calculate the total size of items present in listbox here 
            //}
        }


        private async void getmethod2()
        {


            // string apiUrl = textBox7.Text;
            string apiUrl2 = "https://www.whois.com/whois/" + listBox5.SelectedItem.ToString();
           // MessageBox.Show(apiUrl2);
            // Create an instance of HttpClient
            using (HttpClient client1 = new HttpClient())

            {
                try
                {

                    // Send the GET request
                    client1.DefaultRequestHeaders.UserAgent.ParseAdd("Mozilla/5.0 (compatible; AcmeInc/1.0)");
                    client1.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json; charset=utf-8");
                    HttpResponseMessage response1 = await client1.GetAsync(apiUrl2);

                    // Check if the request was successful (status code 200-299)
                    if (response1.IsSuccessStatusCode)
                    {
                        // Read and print the response content as a string
                        string responseBody1 = await response1.Content.ReadAsStringAsync();
                        textBox17.Text = responseBody1;
                        Console.WriteLine(responseBody1);
                        if (responseBody1.Contains(textBox16.Text))
                            {
                            int selectedprev1 = listBox5.SelectedIndex - 1;
                            string listboxmyselected1 = listBox5.Items[selectedprev1].ToString();

                            richTextBox3.Text += listboxmyselected1 + " Domain owned by: " + textBox16.Text+"\n";
                           // MessageBox.Show("Match Found");
                        }


                    }
                    else
                    {
                        Console.WriteLine($"Error: {response1.StatusCode} - {response1.ReasonPhrase}");
                        textBox17.Text = ($"Error: {response1.StatusCode} - {response1.ReasonPhrase}");

                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Exception: {ex.Message}");
                    MessageBox.Show(ex.Message);

                }
            }

            timer2.Stop();
            timer2.Start();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            listBox3.SelectedIndex = 0;
            apiUrl = listBox3.SelectedItem.ToString();

            timer1.Start();
           // MessageBox.Show((listBox3.Items.Count.ToString()));
        }
        
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
           // MessageBox.Show(start.ToString());
            if (start < listBox3.Items.Count)
            {

                getmethod();

                progressBar1.Maximum = listBox3.Items.Count;
                progressBar1.Step = 1;
                progressBar1.PerformStep();



            }
            
            start++;
            //MessageBox.Show(start.ToString());
            if (start < listBox3.Items.Count)
            {
                listBox3.SelectedItem = listBox3.Items[start];

            }
            else
            {
                timer1.Stop();
            }
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {
             itemtoshow = textBox9.Text;
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            
            if (textBox8.Text.Contains(textBox15.Text))
            {
                selectedprev = listBox3.SelectedIndex - 1;
                listboxmyselected = listBox3.Items[selectedprev].ToString();
                richTextBox1.Text += ("\n" + "HEADER MATCH FOUND FOR :  " + " ") + textBox15.Text + " in the URL :- " + listboxmyselected;

            }
        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (listBox3.SelectedItems.Count != 0)
            {
                while (listBox3.SelectedIndex != -1)
                {
                    listBox3.Items.RemoveAt(listBox3.SelectedIndex);
                }
            }
        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboboxselect = comboBox1.SelectedItem.ToString(); 
            if (comboBox1.SelectedIndex==4)
            {
                textBox12.Text = "//div[@class='compTitle options-toggle']";
                //MessageBox.Show("selected index is : " + comboBox1.SelectedIndex);
                engine = textBox12.Text;
            }
            else if (comboBox1.SelectedIndex == 5)
            {
                textBox12.Text = "//div[@class='tpcn']";
                //MessageBox.Show("selected index is : " + comboBox1.SelectedIndex);
                engine = textBox12.Text;
                textBox10.Text = "&first=81";
            }
            else
            {
                textBox12.Text = "//div[@class='yuRUbf']";
                //MessageBox.Show("selected index is : " + comboBox1.SelectedIndex);
                engine = textBox12.Text;
            }
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void button17_Click(object sender, EventArgs e)
        {
            string[] arr = new string[listBox3.Items.Count];
            listBox3.Items.CopyTo(arr, 0);

            var arr2 = arr.Distinct();

            listBox3.Items.Clear();
            foreach (string s in arr2)
            {
                listBox3.Items.Add(s);
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            progressBar1.Value = 0;
            listBox3.Items.Clear();
            listBox6.Items.Clear();
            start = 0;
            dirb = 0;
            timer1.Stop();
            timer2.Stop();
            timer3.Stop();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex==0)
            {
                textBox13.Text = "\"'";
                textBox9.Text = "You have an error in your";

            }
            else if (comboBox2.SelectedIndex == 1)
            {
                textBox13.Text = "/?"+"\"><b>aaa</b>";
                textBox9.Text = "<b>aaa</b>";
            }
            else if (comboBox2.SelectedIndex == 2)
            {
                textBox13.Text = "/?$&@*()><'`!%^" + "\"#";
                textBox9.Text = "an error occured";
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            
                textBox15.Text = comboBox3.SelectedItem.ToString();
               

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (start < listBox5.Items.Count)
            {

                getmethod2();

                progressBar1.Maximum = listBox4.Items.Count;
                progressBar1.Step = 1;
                progressBar1.PerformStep();



            }

            start++;
            //MessageBox.Show(start.ToString());
            if (start < listBox5.Items.Count)
            {
                listBox5.SelectedItem = listBox5.Items[start];

            }
            else
            {
                timer1.Stop();
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
           

            
            for (int i = 0; i < listBox4.Items.Count; i++)
            {



                listBox4.SelectedItem = listBox4.Items[i];
                string show = listBox4.SelectedItem.ToString();
                GetDomainFromUrl(show);

            }
            //remove duplicates
            string[] arr1 = new string[listBox5.Items.Count];
            listBox5.Items.CopyTo(arr1, 0);

            var arr3 = arr1.Distinct();

            listBox5.Items.Clear();
            foreach (string s in arr3)
            {
                listBox5.Items.Add(s);
            }
        }
        //get domain//
        public string GetDomainFromUrl(string url)
        {
            url = url.Replace("https://", "").Replace("http://", "").Replace("www.", ""); //Remove the prefix
            string[] fragments = url.Split('/');
            
       
            listBox5.Items.Add(fragments[0]);
            return fragments[0];
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox16.Text = comboBox4.SelectedItem.ToString();
        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void button20_Click(object sender, EventArgs e)
        {
        }

        private void button20_Click_1(object sender, EventArgs e)
        {
            listBox6.SelectedIndex = 0;
           string  apiUrl3 = listBox6.SelectedItem.ToString();

            timer3.Start();
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (start < listBox6.Items.Count)
            {

                getmethod3();

                progressBar1.Maximum = listBox6.Items.Count;
                progressBar1.Step = 1;
                progressBar1.PerformStep();



            }

            
            //MessageBox.Show(start.ToString());
            if (start < listBox6.Items.Count)
            {
                listBox6.SelectedItem = listBox6.Items[start];
                start++;

            }
           
            else
            {
                
                timer3.Stop();
                start = 0;
                if (checkBox27.Checked==true)
                {
                    dirb = dirb + 1;
                    int dirbselct = dirb;
                    if (dirbselct < listBox7.Items.Count)
                    {
                        listBox7.SelectedItem = listBox7.Items[dirbselct];
                        timer3.Start();
                        progressBar1.Value = 0;
                    }
                    


                }
               
            }
        }
        //

        private async void getmethod3()
        {

            textBox23.Text = "";
            // string apiUrl = textBox7.Text;
            string apiUrl3 = comboosint + listBox6.SelectedItem;
            if( comboBox5.SelectedIndex==2)
            {
                apiUrl3 = "http://" + listBox6.SelectedItem.ToString()+listBox7.SelectedItem;
                if (listBox7.SelectedIndex==3)
                {
                    apiUrl3 = "https://" + listBox6.SelectedItem.ToString();

                }

            }

            //https://search.censys.io/hosts/186.74.252.155
            //https://search.censys.io/_search/filter?field=services.software.vendor&resource=hosts&virtual_hosts=EXCLUDE&q=google.com
            //https://www.zoomeye.org/api/search?page=1&pageSize=20&t=v4%252Bv6%252Bweb&q=
            //https://www.zoomeye.org/api/search?q=site%253A%2522teslacorp.com%2522&page=1&pageSize=20&t=v4%2Bv6%2Bweb
           // MessageBox.Show(apiUrl3);
            // Create an instance of HttpClient
            //using (HttpClient client2 = new HttpClient())
            using (var client2 = new HttpClient(new HttpClientHandler { UseCookies = false }))
            {
                try
                {

                    // Send the GET request
                    client2.DefaultRequestHeaders.UserAgent.ParseAdd("Mozilla/5.0");
                    //client2.DefaultRequestHeaders.UserAgent.ParseAdd("Mozilla/5.0 (compatible; AcmeInc/1.0)");
                    client2.DefaultRequestHeaders.Add("Cookie", textBox20.Text); ;
                    // client2.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json; charset=utf-8");
                    HttpResponseMessage response2 = await client2.GetAsync(apiUrl3);
                    client2.DefaultRequestHeaders.ConnectionClose = false;
                    foreach (var header in response2.Headers)
                    {
                        Console.WriteLine($"{header.Key}={header.Value.First()}");
                        textBox23.Text += ($"{header.Key}={header.Value.First()}"+"\n");
                    }
                    
                    // Check if the request was successful (status code 200-299)
                    if (response2.IsSuccessStatusCode)
                    {
                        // Read and print the response content as a string
                        string responseBody2 = await response2.Content.ReadAsStringAsync();
                        textBox19.Text = responseBody2;
                        Console.WriteLine(responseBody2);
                        if (responseBody2.Contains(textBox18.Text))
                        {
                            int selectedprev1 = listBox6.SelectedIndex - 1;
                            string listboxmyselected1 = listBox6.Items[selectedprev1].ToString();

                            richTextBox4.Text += listboxmyselected1 + " Matches: " + textBox18.Text + "-"+dirbselected+ "\n";
                            // MessageBox.Show("Match Found");
                        }
                        else if ((textBox23.Text).Contains(textBox18.Text))
                        {
                           
                            int selectedprev1 = listBox6.SelectedIndex - 1;
                            string listboxmyselected1 = listBox6.Items[selectedprev1].ToString();

                            richTextBox4.Text += listboxmyselected1 + " Matches: " + textBox18.Text + "-" + dirbselected+ "\n";
                            // MessageBox.Show("Match Found");
                        }
                       
                    }
                    

                    else
                    {
                        
                        Console.WriteLine($"Error: {response2.StatusCode} - {response2.ReasonPhrase}");
                       // textBox18.Text = ($"Error: {response2.StatusCode} - {response2.ReasonPhrase}");

                    }
                }
                catch (Exception ex)
                {
                    int selectedprev1 = listBox6.SelectedIndex - 1;
                    if (selectedprev1 > 0)
                    {
                        string listboxmyselected1 = listBox6.Items[selectedprev1].ToString();
                        richTextBox4.Text += "Error: " + listBox6.Items[selectedprev1] + ":" + ex.Message + "\n";
                    }
                    else
                    {
                        Console.WriteLine($"Exception: {ex.Message}");
                        richTextBox4.Text += "Error: with index " + ":" + ex.Message + "\n";
                    }
                    
                    //MessageBox.Show(ex.Message);

                }
            }

            timer3.Stop();
            timer3.Start();
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox5.SelectedIndex==1)
            {
                comboosint = "https://www.zoomeye.org/api/search?page=1&pageSize=20&t=v4%252Bv6%252Bweb&q=";
            }
            
            else if (comboBox5.SelectedIndex == 0)
            {
                comboosint = "https://search.censys.io/_search/filter?field=services.software.vendor&resource=hosts&virtual_hosts=EXCLUDE&q=";
            }
            else if (comboBox5.SelectedIndex == 2)
            {
                comboosint = textBox22.Text + listBox7.SelectedItem;
            }
            if ((comboBox5.SelectedIndex == 0) && (checkBox26.Checked == true))
            {
                comboosint = "https://search.censys.io/hosts/";
                //https://search.censys.io/hosts/186.74.252.155

            }
        }

        private void button21_Click(object sender, EventArgs e)
        {
            if (comboBox5.SelectedIndex == 1)
            {
                System.Diagnostics.Process.Start("https://www.zoomeye.org/searchResult?q=" + listBox6.SelectedItem.ToString());
                System.Diagnostics.Process.Start("https://www.zoomeye.org/api/search?page=1&pageSize=20&t=v4%252Bv6%252Bweb&q=" + listBox6.SelectedItem.ToString());

            }
            else if (comboBox5.SelectedIndex == 0)
            {
                System.Diagnostics.Process.Start("https://search.censys.io/search?resource=hosts&sort=RELEVANCE&per_page=25&virtual_hosts=EXCLUDE&q=" + listBox6.SelectedItem.ToString());
                System.Diagnostics.Process.Start("https://search.censys.io/_search/filter?field=services.software.vendor&resource=hosts&virtual_hosts=EXCLUDE&q=" + listBox6.SelectedItem.ToString());

            }
        }

        private void button22_Click(object sender, EventArgs e)
        {
            foreach (var item1 in listBox5.Items)
            {
                listBox6.Items.Add(item1);
            }
        }

        private void button24_Click(object sender, EventArgs e)
        {
             string sPath = textBox21.Text;

            System.IO.StreamWriter SaveFile = new System.IO.StreamWriter(sPath);
            foreach (var item in listBox6.Items)
            {
                SaveFile.WriteLine(item);
            }

            SaveFile.Close();

            MessageBox.Show("Domains saved!");
        }

        private void button23_Click(object sender, EventArgs e)
        {
            listBox6.Items.Clear();
            foreach (var line in System.IO.File.ReadAllLines(textBox21.Text))
            {
                listBox6.Items.Add(line);
            }
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void button25_Click(object sender, EventArgs e)
        {
            string[] arr1 = new string[listBox6.Items.Count];
            listBox6.Items.CopyTo(arr1, 0);

            var arr3 = arr1.Distinct();

            listBox6.Items.Clear();
            foreach (string s1 in arr3)
            {
                listBox6.Items.Add(s1);
            }
        }

        private void listBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox22.Text = "http://"+listBox6.SelectedItem.ToString();
        }

        private void listBox7_SelectedIndexChanged(object sender, EventArgs e)
        {
            dirbselected = listBox7.SelectedItem.ToString();
        }

        private void checkBox27_CheckedChanged(object sender, EventArgs e)
        {
            listBox7.SelectedIndex = 0;
        }

        private void textBox23_TextChanged(object sender, EventArgs e)
        {
           // if ((textBox23.Text).Contains(textBox18.Text))
           // {
           //     int selectedprev1 = listBox6.SelectedIndex - 1;
            //    string listboxmyselected1 = listBox6.Items[selectedprev1].ToString();

           //     richTextBox4.Text += listboxmyselected1 + " Matches: " + textBox18.Text + "-" + dirbselected + "\n";
                // MessageBox.Show("Match Found");
           // }
        }

        private void button26_Click(object sender, EventArgs e)
        {
            string sPath = "logs.txt";

            System.IO.StreamWriter SaveFile = new System.IO.StreamWriter(sPath);
            string item = richTextBox4.Text;
            {
                SaveFile.WriteLine(item);
            }

            SaveFile.Close();

            MessageBox.Show("Logs saved!");
        }

        private void textBox22_TextChanged(object sender, EventArgs e)
        {

            
           // MessageBox.Show("Firstname-- "+s);
           // MessageBox.Show("Changed: + " + listBox7.SelectedIndex.ToString());
            //if (listBox7.SelectedIndex == 3)
            //{
            //    String s = textBox22.Text;
            //    Console.WriteLine("The initial string: '{0}'", s);
            //    s = s.Replace("http", "https");
            //    Console.WriteLine("The final string: '{0}'", s);
            //    textBox22.Text = s;
                //textBox18.Text.Replace(https, str);
           // }

        }

        //
        private void Form1_Load(object sender, EventArgs e)
        {
            itemtoshow = textBox9.Text;
            
        }
    }
}
    









        



        
    


